const mongoose = require('mongoose');
const chalk = require("chalk");
const { USERS_URI, PROPIEDADES_URI } = require('./config');

// En Mongoose 6+, estas opciones ya son el comportamiento por defecto.
// No es necesario definirlas explícitamente.
const optionsMongoose = {
    // useNewUrlParser: true,     <-- ELIMINADO
    // useUnifiedTopology: true,  <-- ELIMINADO
    // useCreateIndex: true       <-- ELIMINADO (Causará error si lo dejas)
}

// ESTA LÍNEA CAUSABA EL ERROR, YA NO EXISTE EN MONGOOSE 6+
// mongoose.set('useFindAndModify', false);  <-- ELIMINADO

class UserConnection{
    static async connect(){
        if(this.db) return this.db;

        let connection;

        try {
            connection = await mongoose.createConnection(this.url, this.options);
            
            //Require models
            require('../../models/user')(connection);

            this.db = connection;

            return this.db;
        } catch (error) {
            console.error("Error conectando a Usuarios:", error); // Es mejor usar console.error
        }
    }
}

UserConnection.db = null;
UserConnection.url = USERS_URI;
UserConnection.options = optionsMongoose;

class PropiedadesConnection{
    static async connect(){
        if(this.db) return this.db;

        let connection;

        try {
            connection = await mongoose.createConnection(this.url, this.options);

            //Require models
            require('../../models/propiedades')(connection);

            this.db = connection;
            
            return this.db;
        } catch (error) {
            console.error("Error conectando a Propiedades:", error);
        }
    }
}

PropiedadesConnection.db = null;
PropiedadesConnection.url = PROPIEDADES_URI;
PropiedadesConnection.options = optionsMongoose;

module.exports = { UserConnection, PropiedadesConnection }