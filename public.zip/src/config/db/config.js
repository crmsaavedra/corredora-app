module.exports = {
    USERS_URI: `${global.link_collection}/users${global.query}`,//:${process.env.MONGO_PORT}
    PROPIEDADES_URI: `${global.link_collection}/propiedades${global.query}`,//:${process.env.MONGO_PORT}
}